package com.gunadhya.diem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GunadhyaDiemApplicationTests {

	@Test
	void contextLoads() {
	}

}
